TOPOGRAPHICAL DATA
IVAN PASPALDZHIEV - DENKSTATT BULGARIA - https://denkstatt.eu/?lang=bg - +359893336957

Based on NASA SRTM digital elevation model.
Approx 20m horizontal accuracy, 10m vertical accuracy (as per satellite mission declared parameters)
Includes Sofia urban area + some areas nominally external to the city (toward Vitosha mountain, note large elevation numbers)
No particular effort has been made to include entirety of Sofia Capital's area as per administrative boundaries

Data description:

Lat - latitude in decimal degrees. This corresponds to Y on a regular 2D grid.
Lon - longitude in decimal degrees. This corresponds to X on a regular 2D grid.
Elev - Elevation in meters.